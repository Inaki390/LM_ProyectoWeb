<?php
function sanitize($data) {
  return htmlspecialchars(stripslashes(trim($data)));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nombre = sanitize($_POST["nombre"]);
  $apellido = sanitize($_POST["apellido"]);
  $movil = sanitize($_POST["movil"]);
  $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
  $mensaje = sanitize($_POST["mensaje"]);

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Correo no válido.");
  }

  // Correo al administrador
  $to_admin = "irazquimen1@educacion.navara.es";
  $subject_admin = "Nuevo mensaje de contacto de $nombre $apellido";
  $message_admin = "Nombre: $nombre $apellido\nMóvil: $movil\nEmail: $email\n\nMensaje:\n$mensaje";
  $headers_admin = "From: $email";

  // Copia al usuario
  $subject_user = "Copia de tu mensaje a Legends Portal";
  $message_user = "Hola $nombre,\n\nGracias por contactarnos. Aquí está una copia de tu mensaje:\n\n$mensaje\n\nNos pondremos en contacto contigo pronto.\n\n- Legends Portal";
  $headers_user = "From: noreply@legendsportal.com";

  // Enviar correos
  mail($to_admin, $subject_admin, $message_admin, $headers_admin);
  mail($email, $subject_user, $message_user, $headers_user);

  header("Location: ../Equipos(Formulario de Contacto)/Equipos.html");
  exit();
} else {
    header("Location: ../Equipos(Formulario de Contacto)/Equipos.html");
    exit(); 
}
?>