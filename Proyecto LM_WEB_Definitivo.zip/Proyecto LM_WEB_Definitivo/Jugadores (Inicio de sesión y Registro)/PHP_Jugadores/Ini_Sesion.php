<?php
$servername = "localhost:3308";
$username = "root";
$password = "";
$dbname = "Lol";
// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS Lol";
if ($conn->query($sql) === TRUE) {
}
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE IF NOT EXISTS Usuarios (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(30) NOT NULL,
    Apellido VARCHAR(30) NOT NULL,
    Email VARCHAR(50) NOT NULL,
    Usuario VARCHAR(30) NOT NULL,
    Contraseña VARCHAR(30) NOT NULL
    )";
    if ($conn->query($sql) === TRUE) {
    }

// Verificar si se enviaron los datos por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escapar valores para evitar SQL Injection
    $Usuario = $conn->real_escape_string($_POST['Usuario']);
    $Contraseña = $conn->real_escape_string($_POST['Contraseña']);

    // Consulta para verificar credenciales
    $sql = "SELECT * FROM Usuarios WHERE Usuario = '$Usuario' AND Contraseña = '$Contraseña'";
    $result = $conn->query($sql);

    // Verificar si encontró un usuario
    if ($result && $result->num_rows > 0) {
        // Redirige si el login fue exitoso
        header("Location: ../../Galeria (Tienda, Campeones, Baneos, Carrusel y Randomizer)\Galeria.php");
        exit();
    }
}

$conn->close();
?>
